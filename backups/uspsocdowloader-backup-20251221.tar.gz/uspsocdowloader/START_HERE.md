# 🚀 Начало разработки UspSocDownloader

## Шаг 1: Откройте проект в VS Code

```powershell
cd D:\DevTools\Database\UspSocDownloader
code .
```

## Шаг 2: Установите зависимости

В терминале VS Code:

```powershell
# Активируйте virtual environment
.\.venv\Scripts\activate

# Обновите pip
python -m pip install --upgrade pip

# Установите зависимости
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

## Шаг 3: Проверьте .env файл

Файл `.env` уже создан с вашим токеном:
```env
BOT_TOKEN=8511650801:AAEGVXeNJeHHhl-ryB8qvQ0dTLTNse-IDK0
BOT_USERNAME=UspSocDownloader_bot
```

## Шаг 4: Начните разработку с Claude Code

### Вариант А: Build with Agent (Рекомендуется)

1. Откройте [README.md](README.md)
2. Нажмите на иконку **Build with Agent** в правом верхнем углу
3. Опишите задачу:

```
Создай базовый Telegram бот для UspSocDownloader

Требования из DEVELOPMENT_PLAN.md (День 1-2):

1. Создать src/config.py:
   - Загрузка настроек из .env
   - Класс Config с параметрами бота

2. Создать src/bot.py:
   - Инициализация Bot и Dispatcher из aiogram 3.x
   - Использовать токен из config

3. Создать src/utils/logger.py:
   - Настройка логирования в файл и консоль
   - Уровни: INFO для продакшна, DEBUG для разработки

4. Создать src/handlers/start.py:
   - Handler для команды /start
   - Приветственное сообщение с описанием бота
   - Список поддерживаемых платформ (Instagram, YouTube, TikTok)

5. Создать src/handlers/help.py:
   - Handler для команды /help
   - Инструкции по использованию
   - Примеры ссылок

6. Создать src/main.py:
   - Entry point приложения
   - Регистрация handlers
   - Запуск polling
   - Graceful shutdown

Используй async/await, aiogram 3.x Router pattern.
Добавь docstrings и type hints.
Следуй структуре из PROJECT_SPEC.md.
```

### Вариант Б: Slash команды

В Claude Code (Ctrl+L):

```
/document src/config.py    # Создаст конфигурацию
/document src/bot.py       # Создаст инициализацию бота
```

### Вариант В: Ручная разработка

Создайте файлы по очереди:

1. `src/config.py` - конфигурация
2. `src/utils/logger.py` - логирование
3. `src/bot.py` - инициализация бота
4. `src/handlers/start.py` - /start команда
5. `src/handlers/help.py` - /help команда
6. `src/main.py` - entry point

## Шаг 5: Запустите бота

```powershell
# Запуск
python src/main.py

# Если бот запустился успешно, увидите:
# INFO - Starting bot...
# INFO - Bot started successfully
```

## Шаг 6: Тестирование

1. Откройте Telegram
2. Найдите @UspSocDownloader_bot
3. Отправьте `/start`
4. Отправьте `/help`

Ожидаемый результат:
- Бот должен ответить приветственным сообщением
- Показать список поддерживаемых платформ
- Дать инструкции

## 📋 Чек-лист первого запуска

- [ ] VS Code открыт
- [ ] Virtual environment активирован
- [ ] Зависимости установлены (`pip install -r requirements.txt`)
- [ ] Файл `.env` существует с токеном
- [ ] Создана структура папок (src/handlers, src/utils, data, logs)
- [ ] Базовые файлы созданы (config.py, bot.py, main.py)
- [ ] Бот запускается без ошибок
- [ ] Бот отвечает на /start и /help

## 🎯 Что дальше (День 3-4)?

После базового бота:

1. **URL Processor** - определение платформы по ссылке
2. **URL Handler** - обработка текстовых сообщений
3. **Validators** - проверка URL

См. [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md) для детального плана.

## 💡 Полезные команды

```powershell
# Запуск с автоперезагрузкой (для разработки)
# Установите nodemon или используйте watchdog
pip install watchdog
watchmedo auto-restart -d src -p '*.py' -- python src/main.py

# Тесты
pytest tests/

# Линтеры
black src tests
flake8 src tests
mypy src

# Логи
tail -f logs/bot.log  # Linux/Git Bash
Get-Content logs/bot.log -Wait  # PowerShell
```

## 📚 Документация

- **[PROJECT_SPEC.md](PROJECT_SPEC.md)** - Полное ТЗ
- **[DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md)** - План на 35 дней
- **[QUICK_START.md](QUICK_START.md)** - Краткая справка

## 🆘 Проблемы?

### Ошибка: "No module named 'aiogram'"
```powershell
pip install -r requirements.txt
```

### Ошибка: "BOT_TOKEN not found"
Проверьте что файл `.env` существует и содержит токен.

### Ошибка при запуске бота
Проверьте логи в `logs/bot.log` или консоль.

### Бот не отвечает
1. Проверьте что бот запущен (python src/main.py)
2. Проверьте токен в .env
3. Убедитесь что бот не запущен в другом месте

---

## ✅ Готово!

После выполнения этих шагов у вас будет:
- ✅ Работающий Telegram бот
- ✅ Ответы на /start и /help
- ✅ Логирование
- ✅ Готовая структура для дальнейшей разработки

**Следующий этап:** URL обработка и скачивание из Instagram

**Удачи в разработке! 🚀**
