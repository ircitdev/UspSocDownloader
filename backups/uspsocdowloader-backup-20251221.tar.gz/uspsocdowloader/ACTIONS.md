# 🚀 Начало разработки - Пошаговые действия

## ✅ Что уже готово

- ✅ Проект создан: `D:\DevTools\Database\UspSocDownloader`
- ✅ Структура директорий создана
- ✅ Виртуальное окружение `.venv` готово
- ✅ Документация готова:
  - [PROJECT_SPEC.md](PROJECT_SPEC.md) - техническая спецификация
  - [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md) - план разработки (35 дней)
  - [START_HERE.md](START_HERE.md) - детальная инструкция
- ✅ `.env` файл создан с токеном бота
- ✅ `requirements.txt` обновлен с нужными пакетами

---

## 📋 Ваши действия СЕЙЧАС

### Шаг 1: Откройте проект в VS Code

```powershell
cd D:\DevTools\Database\UspSocDownloader
code .
```

### Шаг 2: Активируйте виртуальное окружение

**В терминале VS Code (PowerShell):**

```powershell
.\.venv\Scripts\activate.ps1
```

Вы должны увидеть `(.venv)` в начале строки терминала.

### Шаг 3: Установите зависимости

```powershell
pip install -r requirements.txt
```

Это установит:

- `aiogram` - Telegram Bot framework
- `yt-dlp` - универсальный загрузчик медиа
- `aiohttp`, `aiofiles` - асинхронная работа
- `python-dotenv` - работа с .env
- `validators` - валидация URL

### Шаг 4: Проверьте .env файл

Откройте [.env](.env) и убедитесь что токен на месте:

```env
BOT_TOKEN=8511650801:AAEGVXeNJeHHhl-ryB8qvQ0dTLTNse-IDK0
BOT_USERNAME=UspSocDownloader_bot
```

---

## 🤖 Начните разработку с Claude Code

### ⭐ РЕКОМЕНДУЕМЫЙ СПОСОБ: Build with Agent

1. **Откройте [README.md](README.md)**
2. **Нажмите кнопку "Build with Agent"** (правый верхний угол)
3. **Введите задачу:**

```
Создай базовый Telegram бот согласно DEVELOPMENT_PLAN.md (День 1-2)

Задачи:
1. Создать src/config.py - загрузка настроек из .env
2. Создать src/utils/logger.py - настройка логирования
3. Создать src/bot.py - инициализация Bot и Dispatcher
4. Создать src/handlers/start.py - обработчик /start команды
5. Создать src/handlers/help.py - обработчик /help команды
6. Обновить src/main.py - точка входа приложения

Требования:
- Использовать aiogram 3.x
- Async/await стиль
- Загрузка настроек из .env
- Логирование в консоль и файл logs/bot.log
- Обработка ошибок

После создания - запусти бот и протестируй команды /start и /help
```

4. **Claude создаст все файлы и запустит бот**

---

### Альтернатива: Используйте Slash команды

В Claude Code (Ctrl+L):

```
/analyze DEVELOPMENT_PLAN.md
```

Затем:

```
Создай файлы для базового бота (День 1-2 плана)
```

---

## 🧪 Тестирование

После того как Claude создаст файлы:

### 1. Запустите бота

```powershell
python src/main.py
```

Вы должны увидеть:

```
[INFO] Bot started successfully
[INFO] Bot @UspSocDownloader_bot is running...
```

### 2. Протестируйте в Telegram

Откройте Telegram и найдите: **@UspSocDownloader_bot**

Отправьте команды:

- `/start` - должен показать приветствие
- `/help` - должен показать справку

### 3. Остановите бота

Нажмите `Ctrl+C` в терминале

---

## 📖 Следующие шаги (после базового бота)

Следуйте плану в [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md):

- **День 3-4:** URL processor (определение платформы)
- **День 5-7:** Instagram downloader
- **День 8-9:** YouTube downloader
- **День 10-11:** TikTok downloader
- **День 12-14:** Интеграция отправки в Telegram

---

## 🔧 Полезные команды

### Установка dev зависимостей

```powershell
pip install -r requirements-dev.txt
```

Это добавит:

- `pytest` - тестирование
- `black` - форматирование
- `flake8` - линтинг
- `mypy` - проверка типов

### Запуск тестов

```powershell
pytest
```

### Форматирование кода

```powershell
black src tests
```

### Проверка кода

```powershell
flake8 src tests
mypy src
```

---

## 📚 Документация

- [START_HERE.md](START_HERE.md) - детальная инструкция с 3 вариантами разработки
- [PROJECT_SPEC.md](PROJECT_SPEC.md) - полная техническая спецификация
- [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md) - план на 35 дней
- [QUICK_START.md](QUICK_START.md) - краткая справка

---

## ❓ Проблемы?

### Виртуальное окружение не активируется

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Пакеты не устанавливаются

Проверьте подключение к интернету и обновите pip:

```powershell
python -m pip install --upgrade pip
```

### Бот не запускается

1. Проверьте `.env` файл - токен должен быть на месте
2. Проверьте логи в `logs/bot.log`
3. Убедитесь что все пакеты установлены: `pip list`

---

## 🎯 Краткая версия (TL;DR)

```powershell
# 1. Откройте проект
cd D:\DevTools\Database\UspSocDownloader
code .

# 2. Активируйте venv
.\.venv\Scripts\activate.ps1

# 3. Установите пакеты
pip install -r requirements.txt

# 4. Используйте Build with Agent в README.md
# Или попросите Claude Code создать базовый бот

# 5. Запустите
python src/main.py

# 6. Тестируйте в Telegram: @UspSocDownloader_bot
```

---

**Готовы начать? Откройте VS Code и используйте Build with Agent!** 🚀
