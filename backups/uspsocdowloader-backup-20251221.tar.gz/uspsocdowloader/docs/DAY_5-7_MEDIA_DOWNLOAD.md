# День 5-7: Загрузка Медиа ✅

## Реализованные функции

### 1️⃣ Media Downloader (`src/downloaders/media_downloader.py`)

Универсальный загрузчик медиа со всех поддерживаемых платформ.

**Возможности:**

- ✅ Загрузка видео с Instagram, YouTube, TikTok, VK, X
- ✅ Загрузка аудио (VK аудио)
- ✅ Загрузка фото (Instagram, VK)
- ✅ Проверка размера файлов (лимиты: видео 100MB, аудио 50MB, фото 10MB)
- ✅ Асинхронная загрузка (не блокирует бот)
- ✅ Извлечение метаданных (название, длительность, размер)
- ✅ Организация файлов по типам (videos/, audio/, photos/)
- ✅ Очистка старых файлов

**Интеграция с yt-dlp:**

- Использует yt-dlp для универсальной загрузки
- Специальные параметры для каждой платформы
- FFmpeg постпроцессор для конвертации аудио в MP3

### 2️⃣ Download Handler (`src/handlers/download_handler.py`)

Обработчик сообщений с ссылками для инициирования загрузки.

**Функционал:**

- ✅ Автоматическая обработка всех ссылок в сообщениях
- ✅ Сообщение о ходе загрузки
- ✅ Отправка скачанного файла пользователю
- ✅ Показ информации о файле (название, размер, длительность)
- ✅ Обработка ошибок и лимитов

**Как работает:**

1. Пользователь отправляет сообщение со ссылкой
2. Бот распознает платформу
3. Показывает статус "Загрузка контента..."
4. Загружает файл асинхронно
5. Отправляет файл пользователю с информацией
6. Удаляет временное сообщение о загрузке

### 3️⃣ DownloadInfo (`src/downloaders/media_downloader.py`)

Структура данных результата загрузки.

```python
@dataclass
class DownloadInfo:
    success: bool                     # Успешна ли загрузка
    file_path: Optional[str] = None   # Путь к файлу
    file_size: int = 0                # Размер в байтах
    duration: Optional[float] = None  # Длительность в секундах
    title: Optional[str] = None       # Название контента
    error_message: Optional[str] = None  # Сообщение об ошибке
    platform: Optional[str] = None    # Название платформы
```

## Поддерживаемые платформы и типы контента

| Платформа | Видео | Аудио | Фото |
|-----------|-------|-------|------|
| Instagram | ✅ | ❌ | ✅ |
| YouTube | ✅ | ✅ | ❌ |
| TikTok | ✅ | ❌ | ❌ |
| VK | ✅ | ✅ | ✅ |
| X/Twitter | ✅ | ❌ | ❌ |

## Примеры использования

### Загрузка видео

```python
from src.downloaders.media_downloader import MediaDownloader

downloader = MediaDownloader()

# Загрузка видео асинхронно
result = await downloader.download_video(
    url="https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    platform="YouTube"
)

if result.success:
    print(f"✅ Загружено: {result.title}")
    print(f"📊 Размер: {result.file_size / 1024 / 1024:.1f} MB")
    print(f"⏱️ Длительность: {result.duration} сек")
else:
    print(f"❌ Ошибка: {result.error_message}")
```

### Загрузка аудио

```python
# Загрузка аудио (для VK)
result = await downloader.download_audio(
    url="https://vk.com/audio123_456",
    platform="VK"
)
```

### Загрузка фото

```python
# Загрузка фото (для Instagram)
result = await downloader.download_photo(
    url="https://instagram.com/p/ABC123/",
    platform="Instagram"
)
```

### Универсальная загрузка

```python
# Автоматический выбор метода на основе типа контента
result = await downloader.download(
    url="https://vm.tiktok.com/ZMhxxx/",
    content_type="video",
    platform="TikTok"
)
```

## Ограничения и лимиты

| Ресурс | Лимит |
|--------|-------|
| Видео | 100 MB |
| Аудио | 50 MB |
| Фото | 10 MB |
| Таймаут | 30 сек |

## Директории хранения

```
data/
├── videos/      # Скачанные видео
├── audio/       # Скачанное аудио
├── photos/      # Скачанные фото
└── other/       # Другие файлы
```

## Тестирование

### Запуск тестов

```bash
cd D:\DevTools\Database\UspSocDownloader
python -m pytest tests/test_media_downloader.py -v
```

**Результат:** ✅ 16 тестов пройдено

### Тесты включают

- Создание директорий
- Проверка путей для загрузки
- Структура DownloadInfo
- Обработка ошибок
- Конфигурация yt-dlp
- Проверка размеров файлов
- Асинхронные операции

## Статус День 5-7

| Задача | Статус |
|--------|--------|
| Media Downloader | ✅ Готово |
| Поддержка видео | ✅ Готово |
| Поддержка аудио | ✅ Готово |
| Поддержка фото | ✅ Готово |
| Download Handler | ✅ Готово |
| Проверка лимитов | ✅ Готово |
| Метаданные | ✅ Готово |
| Тестирование | ✅ 16/16 ✓ |
| Интеграция с yt-dlp | ✅ Готово |

## Следующие шаги (День 8-10)

### Расширенный функционал

- [ ] Кэширование скачанных файлов (не загружать снова)
- [ ] История загрузок пользователя
- [ ] Статистика загрузок
- [ ] Расширенные опции (качество видео, формат)
- [ ] Загрузка плейлистов

### Оптимизация

- [ ] Сжатие видео перед отправкой
- [ ] Конвертация форматов
- [ ] Параллельная загрузка нескольких файлов
- [ ] Progress bar для длинных загрузок

## Требования

```
aiogram >= 3.0
yt-dlp >= 2024.12
aiofiles >= 24.1
FFmpeg (системный пакет)
```

## Установка зависимостей

```bash
# Основные
pip install -r requirements.txt

# FFmpeg (для обработки аудио)
# Windows (через choco или manual download):
choco install ffmpeg

# Linux:
sudo apt-get install ffmpeg

# macOS:
brew install ffmpeg
```

---

**Дата завершения:** 04.12.2025
**Тесты:** 16 ✅
**Платформы:** 5 (Instagram, YouTube, TikTok, VK, X)
**Типы контента:** видео, аудио, фото
