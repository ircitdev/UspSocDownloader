"""
Локализация - сообщения на русском языке
"""

# Сообщения /start
START_WELCOME = (
    "👋 <b>Привет!</b>\n\n"
    "Я помогу скачать видео, фото и музыку из соцсетей!\n\n"
    "<b>Просто отправь ссылку:</b>\n"
    "• Instagram — посты, Reels, карусели\n"
    "• TikTok — видео без водяного знака\n"
    "• YouTube — видео, Shorts, аудио (MP3)\n"
    "• Twitter/X — видео, фото, GIF\n"
    "• Facebook — видео, Reels\n\n"
    "<b>Примеры ссылок:</b>\n"
    "<code>https://instagram.com/reel/ABC123/</code>\n"
    "<code>https://vm.tiktok.com/ZMxxx/</code>\n"
    "<code>https://youtu.be/dQw4w9WgXcQ</code>\n\n"
    "📖 /help — подробная справка\n"
    "🌐 /platforms — все платформы\n"
    "💎 /premium — безлимитные скачивания"
)

# Сообщения /help
HELP_TEXT = (
    "📖 *Справка по использованию*\n\n"
    "*Основные команды:*\n"
    "/start - показать приветствие\n"
    "/help - показать эту справку\n"
    "/platforms - поддерживаемые платформы\n"
    "/premium - тарифы Premium\n"
    "/stats - ваша статистика\n"
    "/ref - реферальная ссылка\n\n"
    "*Как скачивать медиа:*\n"
    "Просто отправьте ссылку на видео, фото или аудио с одной из поддерживаемых платформ.\n\n"
    "*Примеры ссылок:*\n"
    "`https://instagram.com/p/ABC123/`\n"
    "`https://youtu.be/dQw4w9WgXcQ`\n"
    "`https://vm.tiktok.com/ZMhxxx/`\n\n"
    "*Ограничения (бесплатно):*\n"
    "📥 10 скачиваний в день\n"
    "🎥 YouTube только 360p\n\n"
    "*С Premium:*\n"
    "✅ Безлимитные скачивания\n"
    "✅ HD качество (720p, 1080p)\n\n"
    "⏱️ Загрузка может занять от 5 до 60 секунд."
)

# Сообщения для обработки URL
INVALID_MESSAGE = "❌ Сообщение не содержит ссылку\n\nПожалуйста, отправьте сообщение со ссылкой на:\n• Instagram (посты, реили, истории)\n• YouTube (видео, шорты)\n• TikTok (видео)\n• X/Twitter (твиты)"

INVALID_URL = "❌ Некорректная ссылка\n\nСсылка должна начинаться с http:// или https://"

UNSUPPORTED_PLATFORM = "❌ Неподдерживаемая платформа\n\nПоддерживаем: Instagram, YouTube, TikTok, X/Twitter, Facebook"

# Сообщения для загрузки
DOWNLOAD_STARTED = "⏳ *Загрузка контента...*\n\n{emoji} Платформа: {platform}\n📝 Тип: {content_type}\n\nПожалуйста, подождите..."

DOWNLOAD_SUCCESS = (
    "✅ *Загрузка успешна!*\n\n"
    "📝 Название: {title}\n"
    "📊 Размер: {size_mb:.1f} MB\n"
    "{duration}{platform}"
)

DOWNLOAD_ERROR = "❌ Не удалось загрузить контент\n\n*Ошибка:* {error}"

FILE_SEND_ERROR = "⚠️ Файл загружен но не удалось отправить\n*Ошибка:* {error}"

DOWNLOAD_TIMEOUT = "⏱️ Загрузка заняла слишком много времени. Попробуйте позже."

FILE_TOO_LARGE = "📦 Файл слишком большой (максимум 50 MB)"

NETWORK_ERROR = "🌐 Ошибка подключения. Пожалуйста, попробуйте позже."

CONTENT_NOT_FOUND = "🔍 Контент не найден. Проверьте ссылку."

# Типы контента на русском
CONTENT_TYPES = {
    "video": "видео",
    "photo": "фото",
    "reel": "рилс",
    "story": "история",
    "shorts": "шорты",
    "audio": "аудио",
    "post": "пост",
    "tweet": "твит",
}

# Названия платформ и эмодзи
PLATFORMS = {
    "instagram": ("📷", "Instagram"),
    "youtube": ("🎥", "YouTube"),
    "tiktok": ("🎵", "TikTok"),
    "vk": ("🔵", "VK"),
    "x": ("𝕏", "X"),
    "twitter": ("𝕏", "X"),
    "facebook": ("📘", "Facebook"),
}

# Сообщения об ошибках
ERROR_GENERAL = "❌ Произошла ошибка при обработке ссылки.\nПожалуйста, попробуйте еще раз или используйте /help"

ERROR_BOT_DISABLED = "🤖 Бот временно недоступен. Попробуйте позже."

ERROR_RATE_LIMIT = "⏳ Слишком много запросов. Пожалуйста, подождите перед следующей попыткой."

# Информационные сообщения
INFO_DURATION = "⏱️ Длительность: {minutes}:{seconds:02d}\n"

INFO_PLATFORM_TEMPLATE = "🔗 Платформа: {platform}\n"

SUCCESS_TEMPLATE = "✅ Готово!"

PROCESSING_TEMPLATE = "⏳ Обработка..."

# Статусные сообщения
STATUS_ANALYZING = "🔍 Анализирую ссылку..."
STATUS_DOWNLOADING = "📥 Загружаю файл..."
STATUS_CONVERTING = "🔄 Конвертирую формат..."
STATUS_SENDING = "📤 Отправляю файл..."

# Кнопки (для будущего использования)
BUTTON_HELP = "📖 Справка"
BUTTON_HISTORY = "📋 История"
BUTTON_SETTINGS = "⚙️ Настройки"
